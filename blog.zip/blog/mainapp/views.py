from django.contrib.auth import authenticate
from django.core.checks import messages
from django.shortcuts import render,redirect
from django.views.generic import DetailView, CreateView
from django.urls import reverse_lazy
from .models import News, Category


from django.contrib.auth.forms import UserCreationForm
from hitcount.views import HitCountDetailView
from hitcount.utils import get_hitcount_model
from hitcount.views import HitCountMixin
from django.db.models import Q
from django.core.paginator import Paginator
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages
# home uchun funksiya
def home(request):
    cat = Category.objects.all()
    most_view = News.objects.all().order_by('-date_added')[0:8]
    p = Paginator(News.objects.all(),2)
    page = request.GET.get('page')
    if 'q' in request.GET:
        q = request.GET['q']
        data = News.objects.filter(title__icontains=q)
    else:
        data = News.objects.all()

    datas = p.get_page(page)
    context = {
        'post': data,
        'most_view': most_view,
        'venues': datas,
        'cat': cat
    }
    return render(request, 'home.html', context)
# Ko'rilgan Postlarni sonini hisoblash uchun yozilgan class
class Post(HitCountDetailView):
    model = News
    template_name = 'post.html'
    count_hit = True
# search - Databasedan ma'lumotlarni Qidirish uchun yozilgan funksiya
def search(request):
    if request.method == 'POST':  # agar request.methodi teng bo'lsa POSTga
        searched = request.POST['searched']
        news = News.objects.filter(title__icontains=searched)  # News objectlarini title boyicha filter qilish
        return render(request, 'search.html', {'searched': searched, 'news': news})
    else:  # aks xolda
        return render(request, 'search.html', {})


from django.shortcuts import  render, redirect
from .forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages

def register_request(request):
	ctx = {}
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request,"Muvaffaqiyatli ro'yxatdan o'tdingiz")
			return redirect("login")
		messages.error(request, "Xatolik bor !")
	form = NewUserForm()
	return render (request,"register.html", context={"register_form":form})


from django.contrib.auth import login, authenticate,logout
from django.contrib.auth.forms import AuthenticationForm 
from django.contrib import messages
def login_request(request):
	ctx = {}
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				ctx['message'] = 'xabar yuborildi!'
				return redirect("home")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="login.html", context={"login_form":form})
def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect("home")