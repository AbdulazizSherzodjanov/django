from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('register/', register_request, name='register'),
    path('post/<int:pk>/', Post.as_view(), name='post'),
    path('search/', search, name='search'),
    path("login/", login_request, name="login"),
    path("logout/", logout_request, name= "logout"),
    path("register", register_request, name="register")
]
