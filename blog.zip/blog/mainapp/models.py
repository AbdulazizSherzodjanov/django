from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    title = models.CharField(max_length=250)
    author = models.ForeignKey(User,on_delete=models.CASCADE)
    slug=models.SlugField(max_length=255,unique=True)
    def __str__(self):
        return self.title

class News(models.Model):
    title = models.CharField(max_length=250)
    cat_id = models.ForeignKey(Category,on_delete=models.CASCADE)
    body = models.TextField()
    author = models.ForeignKey(User,on_delete=models.CASCADE)
    date_added = models.DateTimeField(auto_now_add=True)
    image = models.ImageField()
    view = models.IntegerField()
    like = models.IntegerField()
    dislike = models.IntegerField()
    class Meta:
        verbose_name_plural='Yangiliklar'
    def __str__(self):
        return self.title
